import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ebike',
  templateUrl: './ebike.page.html',
  styleUrls: ['./ebike.page.scss'],
})
export class EbikePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
