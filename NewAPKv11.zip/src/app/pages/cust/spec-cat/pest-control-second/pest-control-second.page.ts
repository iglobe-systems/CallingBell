import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pest-control-second',
  templateUrl: './pest-control-second.page.html',
  styleUrls: ['./pest-control-second.page.scss'],
})
export class PestControlSecondPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
